#!/php -q
<?php
// Run from command prompt > php -q chatbot.demo.php
require_once("server/websocket.class.php");


class DemoSocketServer extends WebSocketServer{
	public function __construct(){
		parent::__construct(0,12345);

		// Resource handler for /uri1 URIs
		$this->addResourceHandler('uri1', new Uri1ResourceHandler());
		
		// Resource handler for /uri2 URIs
		$this->addResourceHandler('uri2', new Uri2ResourceHandler());
		
		$this->run();
	}
}

new DemoSocketServer();
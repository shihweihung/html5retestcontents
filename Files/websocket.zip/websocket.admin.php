<?php

class WebSocketAdminMessage extends stdClass{
	public $task = null;
	
	private function __construct(){
	
	}
	
	public static function createGlobalMessage($task){
		$o = new self();
		$o->task = $task;
		
		return $o;
	}
	
	public static function createMessage($resource, $task){
		$o = new self();
		$o->resource = $resource;
		$o->task = $task;
		
		return $o;
	}
	
	public function send($host = '127.0.0.1', $port = 12345){
		$socket=socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		socket_connect($socket, $host, $port);
		
		$msg = json_encode($this);
		
		socket_write($socket, $msg, strlen($msg));
		socket_close($socket);
	}
}
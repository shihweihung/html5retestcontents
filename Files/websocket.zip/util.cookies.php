<?php

function cookie_parse( $line ) {
	$cookies = array();
	$csplit = explode( ';', $line );
	$cdata = array();
	
	foreach( $csplit as $data ) {
		
		$cinfo = explode( '=', $data );
		$key = trim( $cinfo[0] );
		$val = urldecode($cinfo[1]);
		
		$cookies[$key] = $val;
		
	}
	
	return $cookies;
}

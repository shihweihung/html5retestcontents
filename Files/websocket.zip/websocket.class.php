<?php

require_once("util.cookies.php");

require_once("websocket.users.php");
require_once("websocket.framing.php");
require_once("websocket.message.php");
require_once("websocket.resources.php");


class WebSocketServer{
	protected $master;
	protected $sockets = array();
	protected $users   = array();
	protected $debug   = false;
	
	/**
	 * 
	 * Enter description here ...
	 * @var IWebSocketResourceHandler[]
	 */
	protected $resourceHandlers = array();
	
	/**
	 * Flash-policy-response for flashplayer/flashplugin
	 * @access protected
	 * @var string
	 */
	protected $FLASH_POLICY_FILE = "<cross-domain-policy><allow-access-from domain=\"*\" to-ports=\"*\" /></cross-domain-policy>\0";
	

	/**
	 * Handle incoming messages.
	 * 
	 * Must be implemented by all extending classes
	 * 
	 * @param WebSocketUser $user The user which sended the message
	 * @param IWebSocketMessage $msg The message that was received (can be WebSocketMessage76 or WebSocketMessage)
	 */
	
	public function __construct($address,$port){
		error_reporting(E_ALL);
		set_time_limit(0);
		
		ob_implicit_flush();
		
		$this->FLASH_POLICY_FILE = str_replace('to-ports="*','to-ports="'.$port,$this->FLASH_POLICY_FILE);
		
		$this->master=socket_create(AF_INET, SOCK_STREAM, SOL_TCP)     or die("socket_create() failed");
		socket_set_option($this->master, SOL_SOCKET, SO_REUSEADDR, 1)  or die("socket_option() failed");
		
		socket_bind($this->master, $address, $port)                    or die("socket_bind() failed");
		socket_listen($this->master,20)                                or die("socket_listen() failed");
		$this->sockets[] = $this->master;
		
		$this->say("Server Started : ".date('Y-m-d H:i:s'));
		$this->say("Listening on   : ".$address." port ".$port);
		$this->say("Master socket  : ".$this->master."\n");
	}
	
	public function run(){
	// Server loop
		while(true){
			
			// Retreive sockets which are 'Changed'
			$changed = $this->sockets;
			socket_select($changed,$write=NULL,$except=NULL,NULL);
			
			foreach($changed as $socket){
				
				if($socket==$this->master){
					$client=socket_accept($this->master);
					if($client<0){
						self::log('socket_accept() failed'); continue;
					}else $this->connect($client);
					
				}else{
					// TODO: only reads up to 2048 bytes ?
					$bytes = @socket_recv($socket, $buffer, 2048, 0);					
					
					if($bytes == 0) {
						$this->disconnect($socket);
					} else if(strpos($buffer,'<policy-file-request/>') === 0){
						$this->say("FLASH_POLICY_REQUEST");
						socket_write($socket,$this->FLASH_POLICY_FILE,strlen($this->FLASH_POLICY_FILE));
						$this->disconnect($socket);
					} else{
						$this->processSocketRead($socket, $buffer);
					}
				}
			}
		}
	}
	
	protected function processSocketRead($socket, $buffer){
		$user = $this->getuserbysocket($socket);
		
		if($user instanceof WebSocketAdminUser && ($obj = json_decode($buffer)) != null ){
			$this->dispatchAdminMessage($user, $obj);
		} elseif(!$user->handshake)
			$this->dohandshake($user,$buffer);
		else $this->processFrame($user,$buffer);
	}
	
	protected function dispatchAdminMessage(WebSocketAdminUser $user, $obj){				
		if(isset($obj->resource) && array_key_exists($obj->resource, $this->resourceHandlers)){
			$this->resourceHandlers[$obj->resource]->onAdminMessage($user, $obj);
		} else call_user_func(array($this, 'onAdmin'.ucfirst($obj->task)), $user, $obj);
	}
	
	protected function onAdminShutdown(){		
		exit();
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param WebSocketAdminUser $user
	 * @param stdClass $obj
	 * @return bool False to stop event
	 */
	protected function onAdminMessage(WebSocketAdminUser $user, stdClass $obj){
		
		return true;
	}
	
	public function addResourceHandler($script, IWebSocketResourceHandler $handler){
		$this->resourceHandlers[$script] = $handler;
		$handler->setServer($this);
	}

	/**
	 * Process an incoming frame
	 * 
	 * Here it should differentiate between the old single frame protocol and the latest
	 * draft which supports multiple frames per message.
	 *
	 * Control frames will be delegated to WebSocket::processControlFrame(), where other frames
	 * are delegated to WebSocket::onMessageFrame();
	 * 
	 * @param WebSocketUser $user
	 * @param string $msg
	 */
	protected function processFrame(WebSocketUser $user,$msg){
		// Old protocol
		if($user->protocol == 0){
			$msg = WebSocketMessage76::fromFrame(WebSocketFrame76::decode($msg));
			$user->message = $msg;
			$this->dispatchMessage($user, $msg);
		} else {
			// New Protocol
			$frame = WebSocketFrame::decode($msg);
			
			if(WebSocketOpcode::isControlFrame($frame->getType()))
				$this->processControlFrame($user, $frame);
			else $this->processMessageFrame($user, $frame);
		}
	}
	
	/**
	 * Handle incoming control frames
	 *
	 * Sends Pong on Ping and closes the connection after a Close request.
	 * 
	 * @param WebSocketUser $user
	 * @param WebSocketFrame $frame
	 */
	protected function processControlFrame(WebSocketUser $user, WebSocketFrame $frame){
		switch($frame->getType()){
			case WebSocketOpcode::CloseFrame:
				$frame = WebSocketFrame::create(WebSocketOpcode::CloseFrame);
				$this->sendFrame($user, $frame);
				
				$this->disconnect($user->socket);
				break;
			case WebSocketOpcode::PingFrame:
				$frame = WebSocketFrame::create(WebSocketOpcode::PongFrame);
				$this->sendFrame($user, $frame);
				break;
		}
	}
	
	
	/**
	 * Process a Message Frame
	 * 
	 * Appends or creates a new message and attaches it to the user sending it.
	 * 
	 * When the last frame of a message is received, the message is sent for processing to the
	 * abstract WebSocket::onMessage() method.
	 * 
	 * @param WebSocketUser $user
	 * @param WebSocketFrame $frame
	 */
	protected function processMessageFrame(WebSocketUser $user, WebSocketFrame $frame){
		if($user->message instanceof IWebSocketMessage && $user->message->isFinalised() == false)
			$user->message->takeFrame($frame);
		else $user->message = WebSocketMessage::fromFrame($frame);
		
		if($user->message instanceof IWebSocketMessage && $user->message->isFinalised()){
			$this->dispatchMessage($user, $user->message);
		}
	}
	
	protected function dispatchMessage(WebSocketUser $user,IWebSocketMessage $msg){
		if(array_key_exists($user->resource,$this->resourceHandlers)){
			$this->resourceHandlers[$user->resource]->onMessage($user, $user->message);
		}
		
		$this->onMessage($user, $user->message);
	}

	/**
	 * Send a single frame to a client
	 * @param WebSocketUser $client
	 * @param WebSocketFrame $frame
	 */
	public function sendFrame(WebSocketUser $client, WebSocketFrame $frame){
		$msg = $frame->encode();		
		socket_write($client->socket, $msg,strlen($msg));
	}
	
	/**
	 * Send a (text) message to the client

	 * @param WebSocketUser $client
	 * @param string $str
	 */
	public function send(WebSocketUser $client, $str){
		$msg = $client->createMessage($str);
		
		// Sent all fragments
		foreach($msg->getFrames() as $frame){
			$msg = $frame->encode();
			socket_write($client->socket, $msg,strlen($msg));	
		}
	}

	protected function connect($socket){
		$address = '';
		socket_getpeername($socket, &$address);
		 
		if($address == '127.0.0.1')
			$user = new WebSocketAdminUser();
		else {
			$user = new WebSocketUser();
		}

		$user->ip = $address;
		$user->id = uniqid();
		$user->socket = $socket;
		
		// Add to our list
		array_push($this->users,$user);
		array_push($this->sockets,$socket);		
	}
	
	public function disconnectUser(WebSocketUser $user){
		return $this->disconnect($user->socket);
		
		foreach($this->resourceHandlers as $handler){
			$handler->removeUser($user);
		}
	}

	protected function disconnect($socket){	
		// Remove user
		for($i=0; $i < count($this->users); $i++){
			if($this->users[$i]->socket == $socket){
				array_splice($this->users,$i,1);
				break; 
			}
		}
		
		// Remove Socket
		$index = array_search($socket,$this->sockets);
		if($index>=0){
			 array_splice($this->sockets,$index,1); 
		}
		
		$this->say("Disconnected $socket");
		socket_close($socket);
	}

	protected function dohandshake($user,$buffer){		
		$headers = $this->getheaders($buffer);
		$l8b = substr($buffer, -8);
		
		// Check for 2-key based handshake (Hixie protocol draft)
		$key1 = isset($headers['Sec-Websocket-Key1']) ? $headers['Sec-Websocket-Key1'] : null;
		$key2 = isset($headers['Sec-Websocket-Key2']) ? $headers['Sec-Websocket-Key2'] : null;
		
		// Check for newer handshake
		$acceptKey = isset($headers['Sec-Websocket-Key']) ? $headers['Sec-Websocket-Key'] : null;
		
		
		// Origin checking (TODO)
		$origin = isset($headers['Origin']) ? $headers['Origin'] : null;
		$host = $headers['Host'];
		$location = $headers['GET'];

		// Build response
		$response  = "HTTP/1.1 101 WebSocket Protocol Handshake\r\n" .
                "Upgrade: WebSocket\r\n" .
                "Connection: Upgrade\r\n";

		if($key1 != null) {
			// Build HIXIE response
			$response .= "Sec-WebSocket-Origin: $origin\r\n"."Sec-WebSocket-Location: ws://{$host}$location\r\n";
			$response .= "\r\n" . $this->calcKey($key1,$key2,$l8b);
			$user->protocol = 0;
		} else {
			// Build HYBI response
			$response .= "Sec-WebSocket-Accept: ".base64_encode(sha1($acceptKey.'258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true))."\r\n\r\n";
			$user->protocol = 10;
		}
					
		socket_write($user->socket,$response,strlen($response));
		$user->handshake = true;
		
		$this->addUserToResource($user, $headers);

		$user->headers = $headers;
		
		if(isset($headers['Cookie']))
			$user->cookies = cookie_parse($headers['Cookie']);
		else $user->cookies = array();
		
		$this->onConnect($user);
		
		return true;
	}
	
	protected function addUserToResource(WebSocketUser $user, $headers){
		if(isset($headers['GET']) == false)
			return;

		$url = parse_url($headers['GET']);
		
		if(isset($url['query']))
			parse_str($url['query'], $query);
		else $query = array();
		
		$resource = array_pop(preg_split("/\//",$url['path'],0,PREG_SPLIT_NO_EMPTY));
		
		$user->parameters = $query;
		
		
		if(array_key_exists($resource, $this->resourceHandlers)){
			$this->resourceHandlers[$resource]->addUser($user);
			$user->resource = $resource;
		}
	}

	/**
	 * Calculate the #76 draft key based on the 2 challenges from the client and the last 8 bytes of the request
	 * @param string $key1 Sec-WebSocket-Key1
	 * @param string $key2 Sec-Websocket-Key2
	 * @param string $l8b Last 8 bytes of the client's opening handshake
	 */
	private function calcKey($key1,$key2,$l8b){
		//Get the numbers
		preg_match_all('/([\d]+)/', $key1, $key1_num);
		preg_match_all('/([\d]+)/', $key2, $key2_num);
		//Number crunching [/bad pun]
		$this->log("Key1: " . $key1_num = implode($key1_num[0]) );
		$this->log("Key2: " . $key2_num = implode($key2_num[0]) );
		//Count spaces
		preg_match_all('/([ ]+)/', $key1, $key1_spc);
		preg_match_all('/([ ]+)/', $key2, $key2_spc);
		//How many spaces did it find?
		$this->log("Key1 Spaces: " . $key1_spc = strlen(implode($key1_spc[0])) );
		$this->log("Key2 Spaces: " . $key2_spc = strlen(implode($key2_spc[0])) );
		if($key1_spc==0|$key2_spc==0){ $this->log("Invalid key");return; }
		//Some math
		$key1_sec = pack("N",$key1_num / $key1_spc); //Get the 32bit secret key, minus the other thing
		$key2_sec = pack("N",$key2_num / $key2_spc);
		//This needs checking, I'm not completely sure it should be a binary string
		return md5($key1_sec.$key2_sec.$l8b,1); //The result, I think
	}
	
	protected function getheaders( $header )
	{
		$retVal = array();
		$fields = explode("\r\n", preg_replace('/\x0D\x0A[\x09\x20]+/', ' ', $header));
		foreach( $fields as $field ) {
			if( preg_match('/([^:]+): (.+)/m', $field, $match) ) {
				$match[1] = preg_replace('/(?<=^|[\x09\x20\x2D])./e', 'strtoupper("\0")', strtolower(trim($match[1])));
				if( isset($retVal[$match[1]]) ) {
					$retVal[$match[1]] = array($retVal[$match[1]], $match[2]);
				} else {
					$retVal[$match[1]] = trim($match[2]);
				}
			}
		}
		
		if(preg_match("/GET (.*) HTTP/" ,$header,$match)){
			$retVal['GET'] = $match[1]; 
		}
		
		return $retVal;
	}

	protected function getuserbysocket($socket){
		$found=null;
		foreach($this->users as $user){
			if($user->socket==$socket){ $found=$user; break; }
		}
		return $found;
	}
	
	function     log($msg=""){ if($this->debug){ echo $msg."\n"; } }
	function     say($msg=""){ echo $msg."\n";  }
	
	protected function onConnect(WebSocketUser $user){}
	protected function onMessage(WebSocketUser $user, IWebSocketMessage $msg){}
}



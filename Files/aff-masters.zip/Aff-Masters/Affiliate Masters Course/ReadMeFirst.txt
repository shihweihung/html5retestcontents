Dear Affiliate Masters Course registrant,

Targeted traffic is the life-blood of your online business.
An increase in TARGETED traffic produces more SALES which in
turn produces more INCOME for you.  But how do you generate
this type of profitable traffic?

The Affiliate Masters Course offers the total solution.  It
will help you build a Web site that will pull in targeted
traffic (in a way that the Search Engines love!) and that
your visitors will find beneficial due to its solid-gold
content.

You will learn how to create a Theme-Based Content Site... a
site that is loaded with high value Keyword-Focused Pages
that rank highly with the Search Engines *AND* get the click
through to income-generation sources.  The choices for
monetizing your targeted traffic are numerous... from
affiliate merchant sites, to Google's AdSense Program, to
finder's fee relationships, to an online store, to selling
your own product/service, to name just a few.

This process boils down to...

C -> T -> P -> M...

Content -> Traffic -> PREsell -> Monetize

--

The Affiliate Masters Course clearly shows you HOW to follow
the proven C -> T -> P -> M process and build an effective
Theme-Based Content Site that WILL generate income.  NOTHING
has been held back.  EVERYTHING you need to know is included
in the course.

This book, as many students and gurus of "affiliatedom"
have pronounced, is...

   "the best book at succeeding at the affiliate game... 

      at any price... 

         and it's free!" 

Which does, I must admit, lead one to ask...

"So why are you giving it away?"

It's our hope that you'll see that the most cost-effective
way to build a successful site is by using the full Site
Build It! (SBI!) system to carry out all the strategies and
techniques that are outlined in this course.

Like anything with true potential, parts of the Affiliate
Masters Course require some perseverance and effort.
SBI! removes the complex and/or tedious work, allowing you
to focus on what you DO know... your business.

SBI! is the future of Web-hosting.  There's no need to learn
HTML, FTP, Web site design, or the finer points of Search
Engine optimization.  SBI! removes ALL the technology so
that you can SAVE TIME and FOCUS on using your KNOWLEDGE and
PASSION to develop valuable content for your site.


Yes, by offering the "best book of its kind at any price"
FOR FREE, we ARE hoping that you'll see the value of Site
Build It!...

http://buildit.sitesell.com/furtherinfo.html                          

But, as you'll see, if you'd rather do it all manually and
pay for Web hosting separately, ALL the traffic-building
sales-generating information you need is included in The
Affiliate Masters Course, ready for you to use and succeed.

Either way you choose, I wish you the success you deserve.
And you deserve, and WILL get back, whatever you put into
this course.  :-)

--

In your "Affiliate Masters Course" folder, you have 2
files...

1)  ReadMeFirst.txt -- that's what you are reading now!

2)  AffMasters.pdf -- The Affiliate Masters Course will
guide you through a step-by-step "10 DAY" process to
building a traffic-generating, income-producing Theme-Based
Content Site.  The course is written in an
easy-to-understand style and the PDF format is very
"eye-friendly."  Basically, this book makes The Affiliate
Masters Course a straightforward case of "reading and doing."  

Most important piece of advice that I can give you?  The
course "simply works"... if *YOU* work it.

--

Ready to begin?


Just DOUBLE-CLICK on "AffMasters.pdf" to open the file.


SPECIAL NOTE:  You need ADOBE ACROBAT READER 5 (or higher)
to use the Guide.  If you do not have it, please download
now.  It only takes a few minutes to download and install
this free (and fantastic!) software.

> http://www.adobe.com/products/acrobat/readstep2.html


--

OK! It's time to start the transformation... The Affiliate
Masters Course will help you turn your KNOWLEDGE into
CONTENT, your CONTENT into TARGETED TRAFFIC, and your
TRAFFIC into INCOME.

Enjoy the C -> T -> P -> M ride!  :-)

All the best, 
Ken Evoy
President, SiteSell.com

--

More FREE eBooks and Software:
http://www.ezau.com

Brand New Resale Rights:
http://www.ezau.com/resell/

--



